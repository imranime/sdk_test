/*
Copyright (C) SlashNext, Inc. (www.slashnext.com)
License:
Subject to the terms and conditions of this EULA, SlashNext grants to Customer a non transferable,
non-sublicensable,non-exclusive license to use the Software as expresslypermitted in accordance
with Documentation or other specifications published by SlashNext.The Software is solely for Customer's
internal business purposes.All other rights in the Software are expressly reserved by SlashNext.
*/


#import <UIKit/UIKit.h>

//! Project version number for SNXCore.

FOUNDATION_EXPORT double SNXCoreVersionNumber;

//! Project version string for SNXCore.

FOUNDATION_EXPORT const unsigned char SNXCoreVersionString[];


#import <SNXCore/Reachability.h>


